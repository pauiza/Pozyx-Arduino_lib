#include "UM7.h"

#define DREG_EULER_PHI_THETA 0x70	// Packet address sent from the UM7 that contains roll,pitch,yaw and rates.

UM7::UM7() : state(STATE_ZERO){}	// Default constructor

bool UM7::encode(byte c){
	
	switch(state){
	case STATE_ZERO:
		if (c == 's'){
			state = STATE_S;		// Entering state S from state Zero
		} else {
			state = STATE_ZERO;
		}
		return false;
	case STATE_S:
		if (c == 'n'){
			state = STATE_SN;		// Entering state SN from state S
		} else {
			state = STATE_ZERO;
		}
		return false;
	case STATE_SN:
		if (c == 'p'){
			state = STATE_SNP;		// Entering state SNP from state SN.  Packet header detected.
		} else {
			state = STATE_ZERO;
		}
		return false;
	case STATE_SNP:
		state = STATE_PT;			// Entering state PT from state SNP.  Decode packet type.
		packet_type = c;
		packet_has_data = (packet_type >> 7) & 0x01;
		packet_is_batch = (packet_type >> 6) & 0x01;
		batch_length    = (packet_type >> 2) & 0x0F;
		if (packet_has_data){
			if (packet_is_batch){
				data_length = 4 * batch_length;	// Each data packet is 4 bytes long
			} else {
				data_length = 4;
			}
		} else {
			data_length = 0;
		}  
		return false;
	case STATE_PT:
		state = STATE_DATA;		// Next state will be READ_DATA.  Save address to memory. (eg 0x70 for a DREG_EULER_PHI_THETA packet)
		address = c;
		data_index = 0;
		return false;
	case STATE_DATA:			//  Entering state READ_DATA.  Stay in state until all imudata is read.
		imudata[data_index] = c;
		data_index++;
		if (data_index >= data_length){
			state = STATE_CHK1;	//  Data read completed.  Next state will be CHK1
		}
		return false;
	case STATE_CHK1:			// Entering state CHK1.  Next state will be CHK0
		state = STATE_CHK0;
		checksum1 = c;
		return false;
	case STATE_CHK0: 				
		state = STATE_ZERO;		// Entering state CHK0.  Next state will be state Zero.
		checksum0 = c;
		return checksum();
	}
}

bool UM7::checksum(){
	checksum10  = checksum1 << 8;	// Combine checksum1 and checksum0
	checksum10 |= checksum0;
	computed_checksum = 's' + 'n' + 'p' + packet_type + address;
	for (int i = 0; i < data_length; i++){
		computed_checksum += imudata[i];
	}
	if (checksum10 == computed_checksum){
		save();
		return true;
	} else {
		return false;
	}
}

void UM7::save(){
	switch(address){
	case DREG_EULER_PHI_THETA :		// imudata[6] and imudata[7] are unused.
		if(packet_is_batch){
			roll = imudata[0] << 8;
			roll |= imudata[1];
			pitch = imudata[2] << 8;
			pitch |= imudata[3];
			yaw = imudata[4] << 8;
			yaw |= imudata[5];
			roll_rate = imudata[8] << 8;
			roll_rate |= imudata[9];
			pitch_rate = imudata[10] << 8;
			pitch_rate |= imudata[11];
			yaw_rate = imudata[12] << 8;
			yaw_rate |= imudata[13];
			//roll = imudata[0];
		}else{
			roll = imudata[0] << 8;
			roll |= imudata[1];
			pitch = imudata[2] << 8;
			pitch |= imudata[3];
			roll = 10;
		}
		break;
	}
}
