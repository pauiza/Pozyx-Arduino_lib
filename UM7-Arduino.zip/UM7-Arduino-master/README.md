# UM7-Arduino
Binary parser for the CHrobotics UM7 IMU

Library was developed for the Arduino Due microcontroller, but should also be compatible with the Arduino MEGA

Support forum located at

http://www.chrobotics.com/forums/topic/um7-binary-parser-arduino-library

Special thanks to Caleb @ http://www.chrobotics.com/ for making this great product.
